<?php

    include('global.properties');

    $title = $_title;
    $mainmenuindex = 3;
    $content_tmpl = 'index_content';
    $maincontent_tmpl = 'contenthot';

    include('index.tmpl');

?>