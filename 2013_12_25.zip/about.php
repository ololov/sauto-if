<?php

    include('global.properties');

    $title = $_title;
    $mainmenuindex = 1;
    $content_tmpl = 'short_content';
    $maincontent_tmpl = 'contentabout';

    include('index.tmpl');

?>