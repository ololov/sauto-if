<?php

    include('global.properties');

    $title = $_title;
    $mainmenuindex = 4;
    $content_tmpl = 'short_content';
    $maincontent_tmpl = 'contentdelivery';

    include('index.tmpl');

?>