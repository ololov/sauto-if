<?php

    include('global.properties');

    $title = "SAUTO - Admin";
    $mainmenuindex = 2;
    $content_tmpl = 'admin_content';
    $maincontent_tmpl = 'texteditor';

    include('admin.tmpl');

?>