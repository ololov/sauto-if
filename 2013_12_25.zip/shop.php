<?php

    include('global.properties');

    $title = $_title;
    $mainmenuindex = 2;
    $content_tmpl = 'short_content';
    $maincontent_tmpl = 'shop_table';

    include('index.tmpl');

?>