<?php

    include('global.properties');

    $title = $_title;
    $mainmenuindex = 6;
    $content_tmpl = 'short_content';
    $maincontent_tmpl = 'contentcatalog';

    include('index.tmpl');

?>