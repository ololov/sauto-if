<?php

    include('global.properties');

    $title = "SAUTO - Редагування основної промоції";
    $mainmenuindex = 3;
    $content_tmpl = 'admin_content';
    $prom = 'promo';
    $maincontent_tmpl = 'promoeditor';
    $uploader = 'images';

    include('admin.tmpl');

?>