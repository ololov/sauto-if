<?php
    $dir = 'images';
    $files = scandir($dir);
    include('filemanager.tmpl');
    echo 'aaaa';
?>
