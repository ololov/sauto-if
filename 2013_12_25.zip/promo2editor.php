<?php

    include('global.properties');

    $title = "SAUTO - Редагування додаткових промоцій";
    $mainmenuindex = 2;
    $content_tmpl = 'admin_content';
    $prom = 'promo2';
    $maincontent_tmpl = 'promoeditor';
    $uploader = 'images';

    include('admin.tmpl');

?>