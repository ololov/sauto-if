<?php

    include('global.properties');

    $title = "SAUTO - Admin";
    $mainmenuindex = 1;
    $content_tmpl = 'admin_content';
    $maincontent_tmpl = 'adminindex';

    include('admin.tmpl');

?>