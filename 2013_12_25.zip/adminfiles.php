<?php

    include('global.properties');

    $title = "SAUTO - Завантаження файлів";
    $mainmenuindex = 4;
    $content_tmpl = 'admin_content';
    $prom = 'promo';
    $maincontent_tmpl = 'adminfiles';
    $uploader = 'images';

    include('admin.tmpl');

?>