<?php

    include('global.properties');

    $title = "SAUTO - Допомога";
    $mainmenuindex = 4;
    $content_tmpl = 'admin_content';
    $maincontent_tmpl = 'helpindex';

    include('admin.tmpl');

?>